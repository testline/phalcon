#SXD20|20011|50525|50313|2013.12.18 22:15:35|agromat|0|4|25|
#TA categories`8`16384|categories_submissions`8`16384|users`6`16384|users_groups`3`16384
#EOH

#	TC`categories`utf8_unicode_ci	;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_ru` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_ua` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_category_id` int(11) DEFAULT '0',
  `level` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`categories`utf8_unicode_ci	;
INSERT INTO `categories` VALUES 
(57,'Плитка','Плитка',0,0),
(58,'Для ванной','Для ванной',57,1),
(59,'Для кухни','Для кухни',57,1),
(60,'Сантехника','Сантехника',0,0),
(61,'Краны','Краны',60,1),
(62,'Раковины','Раковины',60,1),
(63,'На пол','На пол',58,2),
(64,'На потолок','На потолок',58,2)	;
#	TC`categories_submissions`utf8_unicode_ci	;
CREATE TABLE `categories_submissions` (
  `category_id` int(11) DEFAULT NULL,
  `parent_category_id` int(11) DEFAULT NULL,
  `distance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`categories_submissions`utf8_unicode_ci	;
INSERT INTO `categories_submissions` VALUES 
(58,57,1),
(59,57,1),
(61,60,1),
(62,60,1),
(63,58,1),
(63,57,2),
(64,58,1),
(64,57,2)	;
#	TC`users`utf8_unicode_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_groups_id` int(11) NOT NULL,
  `login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`users`utf8_unicode_ci	;
INSERT INTO `users` VALUES 
(1,1,'developer','qqqq11','Иван','Помидоров',1),
(2,1,'devzone','qqqq11','Сергей','Серёгин',0),
(3,3,'fhfhfdghdfg','qqqq11','fff3','fff',1),
(4,3,'wwww',\N,'ww','ww',\N),
(5,2,'werwerе','qqqq11','rew','wre',0),
(6,2,'ertherth',\N,'etrh3e3e3','erth',\N)	;
#	TC`users_groups`utf8_unicode_ci	;
CREATE TABLE `users_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `user_editing` int(11) DEFAULT NULL,
  `access_editing` int(11) DEFAULT NULL,
  `sections_editing` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`users_groups`utf8_unicode_ci	;
INSERT INTO `users_groups` VALUES 
(1,'Программисты',1,0,1),
(2,'Супервайзеры',0,1,1),
(3,'Менеджеры',0,0,1)	;
