#SXD20|20011|50525|50313|2013.12.06 23:23:07|agromat|0|1|5|
#TA users`5`16384
#EOH

#	TC`users`utf8_unicode_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`users`utf8_unicode_ci	;
INSERT INTO `users` VALUES 
(1,'manager','123456','Иван','Помидоров'),
(2,'manager2','qwert','Георгий','Петров'),
(3,'wer4',\N,'werqwerwer',''),
(4,'rtrrtrt',\N,'rt','rt'),
(5,'ergergr1',\N,'','')	;
