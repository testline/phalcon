#SXD20|20011|50525|50313|2014.01.20 00:01:36|agromat|0|22|77|
#TA access_groups`4`16384|access_users`6`16384|appliances`2`16384|brands`2`16384|categories`8`16384|categories_submissions`8`16384|characteristics`4`16384|characteristics_list_values`2`16384|collections`0`16384|colors`3`16384|forms`2`16384|installments`2`16384|materials`2`16384|measures`2`16384|products`5`16384|products_in_shops`9`16384|sets`2`16384|shops`3`16384|styles`1`16384|surfaces`2`16384|users`5`16384|users_groups`3`16384
#EOH

#	TC`access_groups`utf8_unicode_ci	;
CREATE TABLE `access_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `access` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`access_groups`utf8_unicode_ci	;
INSERT INTO `access_groups` VALUES 
(33,'category',57,1,2),
(34,'category',57,0,3),
(41,'category',60,1,2),
(42,'category',60,1,3)	;
#	TC`access_users`utf8_unicode_ci	;
CREATE TABLE `access_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `access` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`access_users`utf8_unicode_ci	;
INSERT INTO `access_users` VALUES 
(52,'category',57,1,4),
(53,'category',57,1,5),
(54,'category',57,0,6),
(64,'category',60,0,4),
(65,'category',60,0,5),
(66,'category',60,0,6)	;
#	TC`appliances`utf8_unicode_ci	;
CREATE TABLE `appliances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`appliances`utf8_unicode_ci	;
INSERT INTO `appliances` VALUES 
(3,'Для дома'),
(4,'Для офиса')	;
#	TC`brands`utf8_unicode_ci	;
CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`brands`utf8_unicode_ci	;
INSERT INTO `brands` VALUES 
(3,'Pepsi'),
(4,'Sprite')	;
#	TC`categories`utf8_unicode_ci	;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_ru` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_ua` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_category_id` int(11) DEFAULT '0',
  `level` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`categories`utf8_unicode_ci	;
INSERT INTO `categories` VALUES 
(57,'Плитка','Плитка',0,0),
(58,'Для ванной','Для ванной',57,1),
(59,'Для кухни','Для кухни',57,1),
(60,'Сантехника','Сантехника',0,0),
(61,'Краны','Краны',60,1),
(62,'Раковины','Раковины',60,1),
(63,'На пол','На пол',58,2),
(64,'На потолок','На потолок',58,2)	;
#	TC`categories_submissions`utf8_unicode_ci	;
CREATE TABLE `categories_submissions` (
  `category_id` int(11) DEFAULT NULL,
  `parent_category_id` int(11) DEFAULT NULL,
  `distance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`categories_submissions`utf8_unicode_ci	;
INSERT INTO `categories_submissions` VALUES 
(58,57,1),
(59,57,1),
(61,60,1),
(62,60,1),
(63,58,1),
(63,57,2),
(64,58,1),
(64,57,2)	;
#	TC`characteristics`utf8_unicode_ci	;
CREATE TABLE `characteristics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories_id` int(11) DEFAULT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `required` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`characteristics`utf8_unicode_ci	;
INSERT INTO `characteristics` VALUES 
(9,'Диагональ',57,'integer',1),
(10,'Магнетизм',60,'string',1),
(13,'Фасон',57,'select',0),
(14,'Энергетика',60,'float',1)	;
#	TC`characteristics_list_values`utf8_unicode_ci	;
CREATE TABLE `characteristics_list_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `characteristics_id` int(11) DEFAULT NULL,
  `value` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`characteristics_list_values`utf8_unicode_ci	;
INSERT INTO `characteristics_list_values` VALUES 
(13,13,'Средний'),
(14,13,'Небольшой')	;
#	TC`collections`utf8_unicode_ci	;
CREATE TABLE `collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`colors`utf8_unicode_ci	;
CREATE TABLE `colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`colors`utf8_unicode_ci	;
INSERT INTO `colors` VALUES 
(6,'Синий'),
(7,'Зелёный'),
(8,'Красный')	;
#	TC`forms`utf8_unicode_ci	;
CREATE TABLE `forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`forms`utf8_unicode_ci	;
INSERT INTO `forms` VALUES 
(2,'Круглый'),
(3,'Плоский')	;
#	TC`installments`utf8_unicode_ci	;
CREATE TABLE `installments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`installments`utf8_unicode_ci	;
INSERT INTO `installments` VALUES 
(1,'Есть'),
(2,'Нет')	;
#	TC`materials`utf8_unicode_ci	;
CREATE TABLE `materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`materials`utf8_unicode_ci	;
INSERT INTO `materials` VALUES 
(1,'Дерево'),
(2,'Стекло')	;
#	TC`measures`utf8_unicode_ci	;
CREATE TABLE `measures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`measures`utf8_unicode_ci	;
INSERT INTO `measures` VALUES 
(1,'Метр'),
(2,'Километр')	;
#	TC`products`utf8_unicode_ci	;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL DEFAULT '0',
  `code` int(11) DEFAULT NULL,
  `name_r2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_original` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_ru` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_ua` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories_id` int(11) DEFAULT NULL,
  `brands_id` int(11) DEFAULT NULL,
  `collections_id` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `hidden` int(11) DEFAULT NULL,
  `for_sale` int(11) DEFAULT NULL,
  `archived` int(11) DEFAULT NULL,
  `short_description` text COLLATE utf8_unicode_ci,
  `long_description` text COLLATE utf8_unicode_ci,
  `weight` int(11) DEFAULT NULL,
  `measures_id` int(11) DEFAULT NULL,
  `length` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `colors_id` int(11) DEFAULT NULL,
  `materials_id` int(11) DEFAULT NULL,
  `surfaces_id` int(11) DEFAULT NULL,
  `appliances_id` int(11) DEFAULT NULL,
  `styles_id` int(11) DEFAULT NULL,
  `forms_id` int(11) DEFAULT NULL,
  `installments_id` int(11) DEFAULT NULL,
  `sets_id` int(11) DEFAULT NULL,
  `photo1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo4` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo5` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo6` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo7` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo8` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo9` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo10` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`products`utf8_unicode_ci	;
INSERT INTO `products` VALUES 
(5,3,0,'','G1k','Вазон','Вазон',59,4,\N,0,\N,\N,\N,'апр','прт',0,1,0,0,0,6,1,3,4,1,2,1,2,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(6,2,0,'','Кран','Кран','Кран',57,4,\N,0,\N,\N,\N,'','',0,0,0,0,0,0,0,0,0,0,0,0,1,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(7,0,2,'','Плитка','Плитка','Плитка',64,0,\N,0,\N,\N,\N,'hh','',0,0,0,0,0,7,0,0,0,0,0,0,0,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(8,0,0,'','Раковина','Раковина','Раковина',62,4,\N,0,\N,\N,\N,'','',0,0,0,0,0,0,0,0,4,0,0,1,2,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(9,0,0,'','Краник','Краник','Краник',61,0,\N,0,\N,\N,\N,'','',0,0,0,0,0,0,0,0,0,0,0,0,0,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N)	;
#	TC`products_in_shops`utf8_unicode_ci	;
CREATE TABLE `products_in_shops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) DEFAULT NULL,
  `shops_id` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `rebate` float DEFAULT NULL,
  `available` int(11) DEFAULT NULL,
  `availability_updated_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`products_in_shops`utf8_unicode_ci	;
INSERT INTO `products_in_shops` VALUES 
(10,5,1,100,20,0,'0000-00-00'),
(11,5,2,0,0,0,'0000-00-00'),
(12,5,3,0,0,0,'0000-00-00'),
(13,7,1,0,0,1,'0000-00-00'),
(14,7,2,0,0,0,'0000-00-00'),
(15,7,3,0,0,0,'0000-00-00'),
(16,6,1,12,0,1,'0000-00-00'),
(17,6,2,14,12,1,'0000-00-00'),
(18,6,3,5.6,34,0,'0000-00-00')	;
#	TC`sets`utf8_unicode_ci	;
CREATE TABLE `sets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`sets`utf8_unicode_ci	;
INSERT INTO `sets` VALUES 
(1,'В сборе'),
(2,'Полная')	;
#	TC`shops`utf8_unicode_ci	;
CREATE TABLE `shops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`shops`utf8_unicode_ci	;
INSERT INTO `shops` VALUES 
(1,'Магазин 1'),
(2,'Магазин 2'),
(3,'Магазин 3')	;
#	TC`styles`utf8_unicode_ci	;
CREATE TABLE `styles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`styles`utf8_unicode_ci	;
INSERT INTO `styles` VALUES 
(1,'Евроремонт')	;
#	TC`surfaces`utf8_unicode_ci	;
CREATE TABLE `surfaces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`surfaces`utf8_unicode_ci	;
INSERT INTO `surfaces` VALUES 
(2,'Скользкая'),
(3,'Мокрая')	;
#	TC`users`utf8_unicode_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_groups_id` int(11) NOT NULL,
  `login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`users`utf8_unicode_ci	;
INSERT INTO `users` VALUES 
(1,1,'developer','qqqq11','Иван','Помидоров',1),
(2,1,'devzone','qqqq11','Сергей','Серёгин',0),
(4,3,'tiagnu','123456aa','Олег','Тягнибок',1),
(5,2,'yacenuk','qqqq11','Арсений','Яценюк',1),
(6,2,'klichko','qqqq11','Виталий','Кличко',1)	;
#	TC`users_groups`utf8_unicode_ci	;
CREATE TABLE `users_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `user_editing` int(11) DEFAULT NULL,
  `access_editing` int(11) DEFAULT NULL,
  `sections_editing` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`users_groups`utf8_unicode_ci	;
INSERT INTO `users_groups` VALUES 
(1,'Программисты',1,0,1),
(2,'Супервайзеры',0,1,1),
(3,'Менеджеры',0,0,1)	;
